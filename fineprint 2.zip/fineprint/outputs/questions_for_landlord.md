Subject: Questions before I sign the lease

Hello,

Before signing, I would like to clarify a few points in the lease:

1. Can non-renewal notice be given by email, and will you send a reminder before the 90-day cutoff?
2. Does the $300 apply to repairs that are not caused by the tenant, such as a failed water heater?
3. Will the landlord commit to at least 24 hours' notice for non-emergency entry?
4. Which section controls: the 5th-day 5% fee or the 2nd-day $75 charge?
5. What is the process if good-faith discussion does not resolve a dispute?

Thank you,
[Your name]
